<template>
 <hr class="layout">

<div id="container">
    <main id="contents">
        <div id="main_mrap">
            <div class="main_visual">
                <img src="/img/screencapture-empty-seoul-kr-web-banner-20231120-blackday-2-webp-2023-11-30-14_56_22.png" alt="">
            </div>
            <div class="main_visual_button">
                <div class="main_visual_c_wrap">
                    <h2>
                        <span>E( )PTY IS A HIGHLY EXCLUSIVE SELECT SHOP</span>
                    </h2>
                    <section class="collection">
                        <div class="ci-group-l">

                        </div>
                        
                        <div class="ci-group-r">

                        </div>
                    </section>
                </div>

                <div class="main_visual_c_wrap">
                    <div class="xans-product-1">
                        <h2>
                            <span>NEW ARRIVALS</span>
                        </h2>
                        <ul class="prd_list">
                            <li>
                                <div class="box">
                                    <img src="" alt="">
                                    <div class="c-product-detai">
                                        <ul>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="box">
                                    <img src="" alt="">
                                    <div class="c-product-detai">
                                        <ul>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="box">
                                    <img src="" alt="">
                                    <div class="c-product-detai">
                                        <ul>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="box">
                                    <img src="" alt="">
                                    <div class="c-product-detai">
                                        <ul>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="box">
                                    <img src="" alt="">
                                    <div class="c-product-detai">
                                        <ul>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
</template>
<script>
export default {
    name: 'MainComponent',
}
</script>
<style>

</style>